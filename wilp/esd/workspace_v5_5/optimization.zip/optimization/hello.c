#include <stdio.h>

void Copy();
/*
 * hello.c
 */
int main(void) {

	printf(" %d\n" , sizeof (short));
	printf("Hello World!\n");

	Copy();

	while(1){}

	return 0;
}

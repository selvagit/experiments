/*
 * simple_copy.c
 *
 *  Created on: 18-Apr-2019
 *      Author: sveeramani
 */

extern void asm_copy(short *x , short *y, int len);
extern void asm_copy_optimized(short *x , short *y, int len);

void Copy()
{
  int i;
  short x[64] = {0};

  for (i=0;i<64;i++)
  {
	  x[i] = i;
  }

  short y[64] = {0};

  for (i=0;i<64;i++)
  {
	  y[i]= x[i];
  }

  short z[64] = {0};

  asm_copy_opt(x, z, 64);

  memset(z,0,sizeof(z));

  asm_copy_optimized(x, z, 64);
}



